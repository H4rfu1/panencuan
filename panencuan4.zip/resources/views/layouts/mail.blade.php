<h1>Halo {{$name}}</h1>
<p>berikut informai mengenai {{$opsi." ".$judul}} yang anda ikuti.</p>
<p style="white-space: pre;">{{$deskripsi}}</p>