<?php $__env->startSection('judul', 'login'); ?>

<?php $__env->startSection('content'); ?>
    <div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-b-160 p-t-50">
				<form class="login100-form validate-form" method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
					<div class="login100-form-avatar">
						<a href="<?php echo e(url('/')); ?>"><img src="assets/favicon-light.png" alt="AVATAR"></a>
					</div>

					<span class="login100-form-title p-t-20 p-b-45">
					</span>

					<div class="wrap-input100 validate-input m-b-10" data-validate = "Username is required">
						<input class="input100 <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="username" type="text" name="username" value="<?php echo e(old('username')); ?>" required autocomplete="username" placeholder="Username" class="form-control" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-user"></i>
						</span>
					</div>
					<?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?>
							<p class=" text-center text-white"><?php echo e($message); ?></p>
					<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					<div class="wrap-input100 validate-input m-b-10" data-validate = "Password is required">
						<input class="input100 <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="password" name="password" placeholder="Password" required autocomplete="current-password" class="form-control" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-lock"></i>
						</span>
					</div>
					<?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
							<p class=" text-center text-white"><?php echo e($message); ?></p>
					<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

					<!-- <div class="text-center checkbox w-full p-t-10 text-white">
						<label style="font-size: 1em">
						<input type="checkbox" value="" name="remember"  <?php echo e(old('remember') ? 'checked' : ''); ?>>
						<span class="cr"><i class="cr-icon fa fa-check"></i></span>
						<?php echo e(__('Remember Me')); ?>

						</label>
					</div> -->

					<div class="container-login100-form-btn p-t-10">
						<button class="login100-form-btn" type="submit">
                            <?php echo e(__('Login')); ?>

						</button>
					</div>
					<div class="text-center w-full p-t-23">
						<a href="<?php echo e(url('/register')); ?>" class="txt1 float-left" >
							<?php echo e(__('Buat akun')); ?>

						</a>
						<a href="#" class="txt1 float-right">
                        <?php echo e(__('Lupa Password?')); ?>

						</a>
					</div>
				</form>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\aplikasi\xampp\htdocs\panencuan\resources\views/auth/login.blade.php ENDPATH**/ ?>