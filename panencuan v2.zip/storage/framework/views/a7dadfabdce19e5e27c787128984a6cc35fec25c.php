<?php $__env->startSection('judul', 'Komunitas'); ?>
<?php $__env->startSection('judul1', 'Diskusi Komunitas'); ?>

<?php $__env->startSection('content'); ?>
  <div class="page-section">
    <div class="container">
      <div class="row">
      <div class="col-md-12 col-xl-12 chat">
					<div class="card">
						<div class="card-body msg_card_body">
						<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if(Auth::user()->id != $p->id): ?>
							<div class="d-flex justify-content-start">
								<span style="color:white; font-size: 12px;"><?php echo e($p->name); ?></span>
							</div>
							<div class="d-flex justify-content-start mb-4">
								<div class="img_cont_msg">
									<img src="https://static.turbosquid.com/Preview/001292/481/WV/_D.jpg" class="rounded-circle user_img_msg">
								</div>
								<div class="msg_cotainer">
									<?php echo e($p->komentar); ?>

									<span class="msg_time" ><?php echo e(substr($p->tanggal_komen,0,10)); ?></span>
								</div>
							</div>
							<?php else: ?>
								<div class="d-flex justify-content-end">
									<span style="color:white; font-size: 12px;"><?php echo e($p->name); ?></span>
								</div>
							<div class="d-flex justify-content-end mb-4">
								<div class="msg_cotainer_send">
									<?php echo e($p->komentar); ?>

									<span class="msg_time" ><?php echo e(substr($p->tanggal_komen,0,10)); ?></span>
								</div>
								<div class="img_cont_msg">
									<img src="https://static.turbosquid.com/Preview/001292/481/WV/_D.jpg" class="rounded-circle user_img_msg">
								</div>
							</div>
							<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
						<div class="card-footer">
							<form action="<?php echo e(url('kirimpesan')); ?>" method="post">
								<?php echo csrf_field(); ?>
								<input type="hidden" name="id" value="<?php echo e(Auth::user()->id); ?>">
								<div class="input-group">
									<!-- <div class="input-group-append">
										<span class="input-group-text attach_btn"><i class="fa fa-paperclip" aria-hidden="true"></i></span>
									</div> -->
									<textarea name="komen" class="form-control type_msg" placeholder="Type your message..." required></textarea>
									<div class="input-group-append">
									<button type="submit" class="input-group-text send_btn"><i class="fa fa-location-arrow" aria-hidden="true"></i></button>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
      </div>
    </div>
  </div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.temp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\aplikasi\xampp\htdocs\panencuan\resources\views/komunitas/v_groupkomunitas.blade.php ENDPATH**/ ?>