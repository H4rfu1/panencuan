<?php $__env->startSection('judul', 'Video'); ?>
<?php $__env->startSection('judul1', 'Video Pembelajaran'); ?>

<?php $__env->startSection('content'); ?>

  <div class="page-section">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 py-3 container">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="shadow-lg p-3 mb-5 bg-white rounded">
        <article class="blog-entry">
          <div class="post-title"><a href="blog-details.html"><?php echo e($p->judul); ?></a></div>
            <div class="entry-header">
              <div class="post-thumbnail embed-responsive embed-responsive-16by9">
                  <video class="embed-responsive-item" src="<?php echo e(asset('storage/video/'.$p->url_video)); ?>" allowfullscreen controls></video>
              </div>
            </div>
            <div class="entry-meta mb-2">
              <div class="meta-item entry-author">
                <div class="icon">
                  <span class="mai-person"></span>  
                </div>
                pemateri <a href="#"><?php echo e($p->name); ?></a>
              </div>
            </div>
            <div class="entry-content">
              <p><?php echo e($p->deskripsi_video); ?></p>
            </div>
            <!-- <a href="#" class="btn btn-primary">Continue Reading</a> -->
          </article>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.temp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\aplikasi\xampp\htdocs\panencuan\resources\views/member/listPembelajaran.blade.php ENDPATH**/ ?>