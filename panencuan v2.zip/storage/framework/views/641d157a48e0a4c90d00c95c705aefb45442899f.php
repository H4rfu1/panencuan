<?php $__env->startSection('content'); ?>
<!-- page content -->
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="">
        <h3>Kelola Emiten</h3>
        <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                  <div class="x_content">
                    <?php if(Auth::user()->role_id == 3): ?>
                    <a class="btn btn-primary" href="<?php echo e(url('tambahemiten')); ?>">Tambah Analisa Emiten</a>
                    <?php endif; ?>
                    <?php if(session('status')): ?>
                      <div class="alert alert-success alert-dismissible " role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                        </button>
                        <?php echo e(session('status')); ?>

                      </div>
                    <?php endif; ?>

                    <div class="table-responsive">
                      <table class="table table-striped jambo_table bulk_action">
                      <thead>
                          <tr class="headings">
                            <th class="column-title">No. </th>
                            <th class="column-title">Nama Pemateri</th>
                            <th class="column-title">Kode saham </th>
                            <th class="column-title">Health</th>
                            <th class="column-title">Growth</th>
                            <th class="column-title">Value</th>
                            <!-- <th class="column-title no-link last"><span class="nobr">Action</span>
                            </th> -->
                          </tr>
                        </thead>

                        <tbody>
                          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($loop->iteration % 2 == 1): ?>
                          <tr class="even pointer">
                            <td><?php echo e($loop->iteration); ?></td>
                            <td class=" "><?php echo e($p->name); ?></td>
                            <td class=" "><?php echo e($p->kode_saham); ?></td>
                            <td class=" "><?php echo e($p->health); ?></td>
                            <td class=" "><?php echo e($p->growth); ?></td>
                            <td class=" "><?php echo e($p->value); ?></td>
                            <!-- <td class=" last">
                              <a href="<?php echo e(url('video/'.$p->id_video)); ?>/edit"><span class="badge badge-warning" style="font-size: 1em;">Edit</span></a>
                            </td> -->
                          </tr>
                          <?php else: ?>
                          <tr class="odd pointer">
                          <td><?php echo e($loop->iteration); ?></td>
                            <td class=" "><?php echo e($p->name); ?></td>
                            <td class=" "><?php echo e($p->kode_saham); ?></td>
                            <td class=" "><?php echo e($p->health); ?></td>
                            <td class=" "><?php echo e($p->growth); ?></td>
                            <td class=" "><?php echo e($p->value); ?></td>
                            <!-- <td class=" last">
                              <a href="<?php echo e(url('video/'.$p->id_video)); ?>/edit"><span class="badge badge-warning" style="font-size: 1em;">Edit</span></a>
                            </td>                             -->
                          </tr>
                          <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
            </div>
      </div>
    </div>
  </div>
</div>
<!-- /page content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\aplikasi\xampp\htdocs\panencuan\resources\views/pemateri/V_AnalisaEmiten.blade.php ENDPATH**/ ?>