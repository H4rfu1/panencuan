<?php $__env->startSection('judul', 'login'); ?>

<?php $__env->startSection('isi'); ?>
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-b-160 p-t-50">
				<form class="login100-form validate-form">
					<div class="login100-form-avatar">
						<a href="index.html"><img src="assets/favicon-light.png" alt="AVATAR"></a>
					</div>

					<span class="login100-form-title p-t-20 p-b-45">
					</span>

					<div class="wrap-input100 validate-input m-b-10" data-validate = "Username is required">
						<input class="input100" type="text" name="username" placeholder="Username">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-user"></i>
						</span>
					</div>

					<div class="wrap-input100 validate-input m-b-10" data-validate = "Password is required">
						<input class="input100" type="password" name="pass" placeholder="Password">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-lock"></i>
						</span>
					</div>

					<div class="container-login100-form-btn p-t-10">
						<button class="login100-form-btn" onclick="javascript:location.href='<?php echo e(url('/home')); ?>'">
							Login
						</button>
					</div>
					<div class="text-center w-full p-t-23">
						<a href="<?php echo e(url('/register')); ?>" class="txt1 float-left" >
									Buat akun
						</a>
						<a href="#" class="txt1 float-right">
									Lupa password?
						</a>
					</div>
				</form>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\aplikasi\xampp\htdocs\panencuan\resources\views/login.blade.php ENDPATH**/ ?>