<?php $__env->startSection('judul1', 'Analisis Emiten Perusahaan'); ?>
<?php $__env->startSection('judul', 'Analisis Emiten'); ?>

<?php $__env->startSection('content'); ?>
  <div class="page-section">
  <div class="container ">
	<div class="col col-md-12 p-3">
		<div class="row">
			<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<card class="col col-md-6">
				<div class="shadow p-3 mb-5 bg-white rounded">
					<h4>Analisis emiten <?php echo e($p->kode_saham); ?>:</h4>
					Health<span class="pull-right strong"></span>
					<div class="progress">
						<div class="progress-bar bg-info" role="progressbar" aria-valuenow="<?php echo e($p->health); ?>"aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($p->health); ?>%"><?php echo e($p->health / 10); ?></div>
					</div>
					Growth<span class="pull-right strong"></span>
					<div class="progress">
						<div class="progress-bar bg-success" role="progressbar" aria-valuenow="<?php echo e($p->growth); ?>"aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($p->growth); ?>%"><?php echo e($p->growth / 10); ?></div>
					</div>
					
					Value<span class="pull-right strong"></span>
					<div class="progress">
						<div class="progress-bar bg-warning" role="progressbar" aria-valuenow="<?php echo e($p->value); ?>"aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e($p->value); ?>%"><?php echo e($p->value / 10); ?></div>
					</div>
				</div>
			</card>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</div>

  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.temp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\aplikasi\xampp\htdocs\panencuan\resources\views/member/V_AnalisaEmiten.blade.php ENDPATH**/ ?>