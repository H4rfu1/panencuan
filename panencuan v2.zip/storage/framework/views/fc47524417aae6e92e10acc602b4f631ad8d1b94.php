<?php $__env->startSection('judul', 'Daftar'); ?>

<?php $__env->startSection('content'); ?>
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-b-160 p-t-50">
				<form class="login100-form validate-form" method="POST" action="<?php echo e(route('register')); ?>">
					<?php echo csrf_field(); ?>

					<div class="login100-form-avatar">
						<a href="<?php echo e(url('/')); ?>"><img src="assets/favicon-light.png" alt="AVATAR"></a>
					</div>
					<span class="login100-form-title p-t-20 p-b-45">
					</span>

					<div class="wrap-input100 validate-input m-b-10" data-validate = "Name is required">
						<input id="name" class="input100 <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="text" name="name" value="<?php echo e(old('name')); ?>" class="form-control" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')" autocomplete="name" placeholder="Nama Lengkap" >
						<span class="focus-input100">asd</span>
						<span class="symbol-input100">
							<i class="fa fa-user-circle"></i>
						</span>
					</div>
					<div class="wrap-input100 validate-input m-b-10" data-validate = "Username is required">
						<input id="username" class="input100 <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="text" name="username" value="<?php echo e(old('username')); ?>" class="form-control" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')" autocomplete="username" placeholder="Username">
						<span class="focus-input100">asd</span>
						<span class="symbol-input100">
							<i class="fa fa-user"></i>
						</span>
					</div>
					<?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?>
							<p class=" text-center text-white"><?php echo e($message); ?></p>
					<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					<div class="wrap-input100 validate-input m-b-10" data-validate = "Email is required">
						<input id="email"  class="input100 <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')" autocomplete="email" placeholder="Email">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-envelope"></i>
						</span>
					</div>
					<?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
							<p class=" text-center text-white"><?php echo e($message); ?></p>
					<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

					<div class="wrap-input100 validate-input m-b-10" data-validate = "Username is required">
						<input id="jenis_kelamin" class="input100 <?php if ($errors->has('jenis_kelamin')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('jenis_kelamin'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="text" name="jenis_kelamin" value="<?php echo e(old('jenis_kelamin')); ?>" required autocomplete="jenis_kelamin" placeholder="Jenis Kelamin" class="form-control" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')">
						<span class="focus-input100">asd</span>
						<span class="symbol-input100">
							<i class="fa fa-venus-mars"></i>
						</span>
					</div>

					<div class="wrap-input100 validate-input m-b-10" data-validate = "Username is required">
						<input id="tanggal" class="input100 <?php if ($errors->has('tanggal')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('tanggal'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="date" name="tanggal" value="<?php echo e(old('tanggal')); ?>" class="form-control" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')" autocomplete="tanggal" placeholder="Tanggal Lahir">
						<span class="focus-input100">asd</span>
						<span class="symbol-input100">
							<i class="fa fa-calendar"></i>
						</span>
					</div>

					<div class="wrap-input100 validate-input m-b-10" data-validate = "Username is required">
						<input id="kota" class="input100 <?php if ($errors->has('kota')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('kota'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="text" name="kota" value="<?php echo e(old('kota')); ?>" class="form-control" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')" autocomplete="kota" placeholder="Kota">
						<span class="focus-input100">asd</span>
						<span class="symbol-input100">
							<i class="fa fa-building"></i>
						</span>
					</div>

					<div class="wrap-input100 validate-input m-b-10" data-validate = "Username is required">
						<input id="no_hp" class="input100 <?php if ($errors->has('no_hp')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('no_hp'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="text" name="no_hp" value="<?php echo e(old('no_hp')); ?>" class="form-control" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')" autocomplete="no_hp" placeholder="No. HP">
						<span class="focus-input100">asd</span>
						<span class="symbol-input100">
							<i class="fa fa-phone"></i>
						</span>
					</div>

					<div class="wrap-input100 validate-input m-b-10" data-validate = "Username is required">
						<input id="nim" class="input100 <?php if ($errors->has('nim')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nim'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="text" name="nim" value="<?php echo e(old('nim')); ?>" class="form-control" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')" autocomplete="nim" placeholder="NIM">
						<span class="focus-input100">asd</span>
						<span class="symbol-input100">
							<i class="fa fa-id-card"></i>
						</span>
					</div>

					<div class="wrap-input100 validate-input m-b-10" data-validate = "Username is required">
						<input id="jurusan" class="input100 <?php if ($errors->has('jurusan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('jurusan'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="jurusan" name="jurusan" value="<?php echo e(old('jurusan')); ?>" class="form-control" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')" autocomplete="jurusan" placeholder="Jurusan">
						<span class="focus-input100">asd</span>
						<span class="symbol-input100">
							<i class="fa fa-industry"></i>
						</span>
					</div>

					<div class="wrap-input100 validate-input m-b-10" data-validate = "Password is required">
						<input id="password" class="input100 <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" class="form-control" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')" autocomplete="new-password" type="password" placeholder="Password">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-lock"></i>
						</span>
					</div>
					<?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
							<p class=" text-center text-white"><?php echo e($message); ?></p>
					<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					<div class="wrap-input100 validate-input m-b-10" data-validate = "Password is required">
						<input class="input100" type="password" name="password_confirmation" placeholder="Konfirmasi Password" id="password-confirm" class="form-control" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')" autocomplete="new-password">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-lock"></i>
						</span>
					</div>

					<div class="container-login100-form-btn p-t-10">
						<button class="login100-form-btn" type="submit">
							<?php echo e(__('Daftar')); ?>

						</button>
					</div>
					<div class="text-center w-full p-t-23">
						<a href="<?php echo e(url('/login')); ?>" class="txt1 float-left" >
									<?php echo e(__('Login')); ?>

						</a>
						<a href="#" class="txt1 float-right">
									<?php echo e(__('Lupa password?')); ?>

						</a>
					</div>
				</form>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\aplikasi\xampp\htdocs\panencuan\resources\views/auth/register.blade.php ENDPATH**/ ?>